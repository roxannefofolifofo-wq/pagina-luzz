import React from 'react';

const Welcome: React.FC = () => {
    return (
        <div className="text-center py-10 px-6 bg-white rounded-2xl shadow-lg border border-gray-200/50">
            <div className="flex justify-center mb-4">
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                 </svg>
            </div>
            <h2 className="text-2xl font-bold text-gray-800">Encontremos Tu Escuela Perfecta</h2>
            <p className="mt-2 text-gray-600 max-w-xl mx-auto">
                Completa el formulario para comenzar. Nuestra IA analizará tu perfil para encontrar las escuelas en Santa Fe que mejor se adapten a ti, ya sea jardín, primaria o secundaria.
            </p>
        </div>
    );
};

export default Welcome;