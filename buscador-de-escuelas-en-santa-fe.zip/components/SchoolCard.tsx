import React from 'react';
import type { School } from '../types';

interface SchoolCardProps {
  school: School;
}

const SchoolCard: React.FC<SchoolCardProps> = ({ school }) => {
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300 border border-gray-200/80">
      <div className="p-6 sm:p-8">
        <div className="flex items-center space-x-4 mb-6">
            <div className="flex-shrink-0">
                <div className="h-12 w-12 rounded-full bg-gradient-to-br from-indigo-500 to-blue-500 flex items-center justify-center">
                    <svg xmlns="https://www.w3.org/2000/svg" className="h-7 w-7 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path d="M12 14l9-5-9-5-9 5 9 5z" />
                      <path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-5.998 12.078 12.078 0 01.665-6.479L12 14z" />
                      <path strokeLinecap="round" strokeLinejoin="round" d="M12 14l9-5-9-5-9 5 9 5zm0 0v6" />
                    </svg>
                </div>
            </div>
            <div>
                 <h3 className="text-xl font-bold text-gray-900">{school.name}</h3>
            </div>
        </div>
        
        <p className="text-gray-600 text-sm leading-relaxed">{school.description}</p>

        <div className="mt-6">
          <h4 className="text-sm font-semibold text-gray-800 mb-3">Especialidades Clave:</h4>
          <div className="flex flex-wrap gap-2">
            {school.specialties.map((specialty, index) => (
              <span 
                key={index} 
                className="px-3 py-1 text-xs font-semibold text-indigo-900 bg-gradient-to-br from-indigo-100 to-blue-100 rounded-full transition-transform duration-200 ease-in-out hover:scale-105 hover:shadow-sm"
              >
                {specialty}
              </span>
            ))}
          </div>
        </div>

        <div className="mt-6 pt-6 border-t border-gray-200/80">
          <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 pt-0.5">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-500" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
              </div>
              <div>
                  <h4 className="text-sm font-semibold text-gray-800">Por qué es una gran opción:</h4>
                  <p className="mt-1 text-sm text-gray-600 leading-relaxed">{school.reason}</p>
              </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SchoolCard;