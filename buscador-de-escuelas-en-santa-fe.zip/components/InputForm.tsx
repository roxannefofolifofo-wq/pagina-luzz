import React, { useState } from 'react';
import type { UserProfile } from '../types';

interface InputFieldProps {
  id: keyof UserProfile;
  label: string;
  value: string;
  error?: string;
  placeholder: string;
  as?: 'input' | 'textarea' | 'select';
  rows?: number;
  description?: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => void;
  children?: React.ReactNode;
}

const InputField: React.FC<InputFieldProps> = ({ id, label, value, error, placeholder, as = 'input', rows = 3, description, onChange, children }) => {
    const errorId = `${id}-error`;
    const commonClasses = `block w-full rounded-lg bg-white text-gray-900 border-gray-500 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm transition duration-150 ${error ? 'border-red-500 ring-red-500' : ''}`;

    const renderInput = () => {
        switch (as) {
            case 'textarea':
                return (
                    <textarea
                        id={id}
                        name={id}
                        value={value}
                        onChange={onChange}
                        placeholder={placeholder}
                        rows={rows}
                        aria-invalid={!!error}
                        aria-describedby={error ? errorId : undefined}
                        className={commonClasses}
                    />
                );
            case 'select':
                return (
                    <select
                        id={id}
                        name={id}
                        value={value}
                        onChange={onChange}
                        aria-invalid={!!error}
                        aria-describedby={error ? errorId : undefined}
                        className={commonClasses}
                    >
                       {children}
                    </select>
                );
            default:
                return (
                    <input
                        type={id === 'age' ? 'number' : 'text'}
                        id={id}
                        name={id}
                        value={value}
                        onChange={onChange}
                        placeholder={placeholder}
                        aria-invalid={!!error}
                        aria-describedby={error ? errorId : undefined}
                        className={commonClasses}
                    />
                );
        }
    };
    
    return (
        <div>
          <label htmlFor={id} className="block text-sm font-semibold text-gray-700">
            {label}
          </label>
           {description && <p className="text-xs text-gray-500 mt-1 mb-1">{description}</p>}
           <div className="mt-1">
             {renderInput()}
           </div>
          {error && <p id={errorId} className="mt-1 text-xs text-red-600">{error}</p>}
        </div>
    );
};


interface InputFormProps {
  onSubmit: (profile: UserProfile) => void;
  isLoading: boolean;
}

const InputForm: React.FC<InputFormProps> = ({ onSubmit, isLoading }) => {
  const [profile, setProfile] = useState<UserProfile>({
    age: '',
    level: '',
    neighborhood: '',
    busLines: '',
    skills: '',
    likes: '',
    dislikes: '',
    sources: '',
  });
  
  const [errors, setErrors] = useState<Partial<UserProfile>>({});

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setProfile(prev => ({ ...prev, [name]: value }));
  };

  const handleClear = () => {
    setProfile({ age: '', level: '', neighborhood: '', busLines: '', skills: '', likes: '', dislikes: '', sources: '' });
    setErrors({});
  };
  
  const validate = () => {
    const newErrors: Partial<UserProfile> = {};
    if (!profile.level) newErrors.level = "El nivel educativo es requerido.";

    if (!profile.age) newErrors.age = "La edad es requerida.";
    else if (isNaN(Number(profile.age)) || Number(profile.age) < 3 || Number(profile.age) > 18) {
      newErrors.age = "Por favor, ingresa una edad válida (3-18).";
    }

    if (!profile.skills.trim()) newErrors.skills = "Las habilidades son requeridas.";
    if (!profile.likes.trim()) newErrors.likes = "Los gustos son requeridos.";
    if (!profile.dislikes.trim()) newErrors.dislikes = "Las cosas que no le gustan son requeridas.";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit(profile);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div>
        <h2 className="text-xl font-bold text-gray-800">Criterios de Búsqueda</h2>
        <p className="text-sm text-gray-500 mt-1">Completa los datos para encontrar la mejor escuela.</p>
        <div className="mt-6 grid grid-cols-1 gap-x-6 gap-y-6 sm:grid-cols-2">
            <InputField id="level" label="Nivel Educativo" as="select" value={profile.level} error={errors.level} onChange={handleChange} placeholder="">
              <option value="">Selecciona un nivel</option>
              <option value="Jardín">Jardín</option>
              <option value="Primaria">Primaria</option>
              <option value="Secundaria">Secundaria</option>
            </InputField>
            <InputField id="age" label="Edad del Estudiante" value={profile.age} error={errors.age} placeholder="Ej: 15" onChange={handleChange} />
            <InputField id="neighborhood" label="Barrio de preferencia (Opcional)" value={profile.neighborhood} placeholder="Ej: Centro, Candioti Norte" onChange={handleChange} />
            <InputField id="busLines" label="Líneas de colectivo cercanas (Opcional)" value={profile.busLines} placeholder="Ej: Línea 14, 8, 16" onChange={handleChange} />
        </div>
      </div>
       
      <div>
        <h2 className="text-xl font-bold text-gray-800">Perfil del Estudiante</h2>
        <p className="text-sm text-gray-500 mt-1">Cuantos más detalles, mejores serán las recomendaciones.</p>
        <div className="mt-6 grid grid-cols-1 gap-x-6 gap-y-6">
          <InputField id="skills" label="Habilidades del Estudiante" value={profile.skills} error={errors.skills} placeholder="Ej: Matemáticas, pintura, programación, sociable" onChange={handleChange} />
          <InputField id="likes" label="Gustos e Intereses" as="textarea" value={profile.likes} error={errors.likes} placeholder="Ej: Deportes en equipo, libros de ciencia ficción, club de robótica" onChange={handleChange} />
          <InputField id="dislikes" label="Cosas que no le gustan y evita" as="textarea" value={profile.dislikes} error={errors.dislikes} placeholder="Ej: Grandes multitudes, ambientes muy competitivos" onChange={handleChange} />
          <InputField 
             id="sources" 
             label="URLs de Escuelas (Opcional)" 
             as="textarea"
             rows={4} 
             value={profile.sources} 
             placeholder="Ej: https://escuela1.com, https://escuela2.edu.ar"
             description="Pega una o más URLs separadas por comas o saltos de línea. Estas fuentes tendrán prioridad sobre nuestra lista predeterminada."
             onChange={handleChange}
          />
       </div>
      </div>
       
       <div className="flex flex-col sm:flex-row-reverse sm:items-center sm:justify-start gap-3 pt-2">
          <button
            type="submit"
            disabled={isLoading}
            className="w-full sm:w-auto flex justify-center py-3 px-6 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-400 disabled:cursor-not-allowed transition-colors duration-200"
          >
            {isLoading ? 'Buscando escuelas...' : 'Encontrar Mi Escuela'}
          </button>
          <button
            type="button"
            onClick={handleClear}
            disabled={isLoading}
            className="w-full sm:w-auto flex justify-center py-3 px-6 border border-indigo-600 rounded-lg shadow-sm text-sm font-medium text-indigo-600 bg-white hover:bg-indigo-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
          >
            Limpiar Formulario
          </button>
       </div>
    </form>
  );
};

export default InputForm;