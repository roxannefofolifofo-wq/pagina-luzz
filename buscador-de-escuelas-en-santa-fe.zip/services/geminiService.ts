import { GoogleGenAI, Type } from "@google/genai";
import type { School, UserProfile } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const schoolSchema = {
  type: Type.OBJECT,
  properties: {
    name: {
      type: Type.STRING,
      description: 'El nombre de la institución educativa (jardín, escuela primaria o secundaria).',
    },
    description: {
      type: Type.STRING,
      description: 'Una breve descripción del enfoque, la cultura y el ambiente de la institución.',
    },
    specialties: {
      type: Type.ARRAY,
      items: {
        type: Type.STRING,
      },
      description: 'Una lista de especialidades clave, programas académicos, orientaciones o fortalezas extracurriculares.',
    },
    reason: {
      type: Type.STRING,
      description: 'Una razón específica que explica por qué esta escuela es una gran opción para el estudiante, haciendo referencia directa a su perfil, incluyendo cercanía, transporte y preferencias personales.',
    },
  },
  required: ['name', 'description', 'specialties', 'reason']
};

const DEFAULT_SCHOOLS = `
- IPEI (Instituto Privado de Educación Integral) - https://www.ipei1291.edu.ar/ipei/
- IASFe (Instituto Adventista de Santa Fe) - https://iasfe.educacionadventista.com/
- EIS (Escuela Industrial Superior) - https://www.eis.unl.edu.ar/
- Colegio Sagrado Corazón - https://sagradocorazonsf.edu.ar/
- Colegio El Calvario - https://sites.google.com/calvariosantafe.edu.ar/colegio
- Colegio Sagrada Familia - http://sagradafamiliarosario.edu.ar/
- Colegio Nuestra Señora del Huerto - http://www.ntrasradelhuertosantafe.edu.ar/
- Escuela N° 7 Presidente Beleno
- Escuela Normal Superior N° 32 "Gral. José de San Martín" - https://www.escuelanormal32.edu.ar/
- E.E.T.P. N° 479 "Dr. Manuel D. Pizarro" - https://www.eetp479pizarro.edu.ar/
- Escuela Provincial de Artes Visuales "Prof. Juan Mantovani" - https://www.lamantovani.edu.ar/
- Escuela de Enseñanza Media N° 263 "Mariano Moreno" - https://escuelamarianomoreno.blogspot.com/
- Colegio Nuestra Señora de Guadalupe - https://escuelansguadalupe.edu.ar/
- E.E.T.P. N° 478 "Dr. Nicolás Avellaneda" - https://eetp478.blogspot.com/
- Colegio Don Bosco - https://www.instagram.com/secundariadonbosco.sf
- Colegio San Eugenio - https://escuelasaneugenio.edu.ar/
- Colegio Nuestra Señora de Covadonga - https://www.centroasturiano.org.ar/Colegio-Nuestra-Senora-Covadonga-Asturiano-Santa-Fe.html
- Colegio Grilli - https://sites.google.com/view/lagrilli263/
- Colegio Jerárquicos - https://cejs.edu.ar/
- Instituto Almirante Brown - https://www.institutobrown.edu.ar/
- Escuela N° 25 "Luis María Drago"
- Colegio San José Adoratrices - https://www.sanjoseadoratricessf.edu.ar/
- Colegio La Salle Jobson - https://www.lasallejobson.edu.ar/
- Colegio Juana del Pino - https://www.juanadelpino.edu.ar/
- IES (Instituto de Educación Superior) - https://iessantafe.edu.ar/
- Colegio San José Arquidiocesano - https://cesanjose.com.ar/
- Escuela Dante Alighieri - https://uybdantealighierisf.org.ar/
- Colegio de la Inmaculada Concepción - https://www.colegioinmaculada.edu.ar/
- Escuela La Toldería
- Escuela Verna
- CREI (Centro Recreativo Estético Infantil)
- Escuela Sara Faisal
- Colegio San Ezequiel Moreno
- Escuela Bustos
- Colegio de Fátima
- Escuela de Enseñanza Media N° 389 "Julio Migno" (Manuel Belgrano)
`;


export async function getSchoolRecommendations(profile: UserProfile): Promise<School[]> {
    
    let sourceMaterial: string;
    let sourceInstruction: string;

    if (profile.sources.trim()) {
        sourceMaterial = `
Fuentes Proporcionadas por el Usuario (Prioridad Alta):
${profile.sources.trim()}

---

Lista de Escuelas Predeterminada (Fuente Secundaria):
${DEFAULT_SCHOOLS}
        `;
        sourceInstruction = "Basa tus recomendaciones principalmente en las 'Fuentes Proporcionadas por el Usuario'. Si es necesario, puedes complementar con la 'Lista de Escuelas Predeterminada' o tu conocimiento general sobre escuelas en Santa Fe, Argentina. Analiza el contenido de las URLs para obtener información detallada. No inventes ninguna escuela.";
    } else {
        sourceMaterial = DEFAULT_SCHOOLS;
        sourceInstruction = "Usa la siguiente lista de escuelas y tu conocimiento general sobre instituciones educativas en Santa Fe, Argentina como tu fuente de información. Selecciona las 3 mejores coincidencias de esta lista. No inventes ninguna escuela.";
    }

    const prompt = `
        Eres un consultor educativo experto, especializado en el sistema educativo completo (jardín, primaria y secundaria) de la ciudad de Santa Fe, Argentina. Tu objetivo es ayudar a las familias a encontrar la escuela perfecta.
        Basado en el siguiente perfil de estudiante y familia, recomienda las 3 instituciones educativas más adecuadas.
        Para cada una, proporciona un nombre, una breve descripción de su enfoque y cultura, una lista de sus especialidades o programas clave, y una razón específica por la que es una buena opción para este estudiante, considerando todos los factores.

        FACTORES CRÍTICOS A CONSIDERAR:
        1. Nivel Educativo: Asegúrate de que la recomendación corresponda al nivel solicitado.
        2. Ubicación: Prioriza escuelas dentro o cerca del 'Barrio de Preferencia'. Menciona la cercanía en tu razón.
        3. Transporte: Considera la conveniencia de las 'Líneas de colectivo cercanas' si se especifican.

        IMPORTANTE: ${sourceInstruction}

        Fuentes de Información Disponibles:
        ---
        ${sourceMaterial}
        ---

        Perfil del Estudiante y Familia:
        - Nivel Educativo Buscado: ${profile.level}
        - Edad del Estudiante: ${profile.age}
        - Barrio de Preferencia: ${profile.neighborhood}
        - Líneas de colectivo de interés: ${profile.busLines}
        - Habilidades Clave del Estudiante: ${profile.skills}
        - Gustos / Intereses del Estudiante: ${profile.likes}
        - El Estudiante evita o no le gusta: ${profile.dislikes}

        Por favor, proporciona tu respuesta como un array de objetos JSON válido.
    `;
    
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: schoolSchema,
                },
            },
        });
        
        const responseText = response.text.trim();
        const schoolData = JSON.parse(responseText);
        
        // Basic validation
        if (!Array.isArray(schoolData)) {
            throw new Error("Formato de respuesta inválido de la API. Se esperaba un array.");
        }
        
        return schoolData as School[];

    } catch (error) {
        console.error("Error fetching school recommendations:", error);
        throw new Error("Fallo al obtener recomendaciones de la API de Gemini.");
    }
}